#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<iostream>
#include<algorithm>
// you can add more const number here...
#define PI 3.1415926

using namespace std;

// if you want to add a new class
// string Type = "Name you want print"
string R = "Rectangle";
string C = "Circle";
string T = "Triangle";

struct segment{
    double value;
    string name;
};

bool operator<(const struct segment &x, const struct segment &y)
{
    return x.value < y.value;
}

class Shape{
    public:
        string name;
        string Name(){
            return name;
        }
        virtual double getArea() = 0;
    Shape(string name){
        this->name = name;
    }
};

/* if you want to add a new class:
class NewClass: public Shape{
    private:
       a lot of attributes
    public:
        double getArea(){
            return the area;
        }
    NewClass():Shape(Type you define at first);
}*/

class Triangle: public Shape{
    private:
        int a;
        int b;
        int c;
    public:
        double getArea(){
            double p = (a+b+c)*1.0 / 2;
            return sqrt(p*(p-a)*(p-b)*(p-c));
        }
    Triangle(int a,int b,int c):Shape(T){
        this->a = a;
        this->b = b;
        this->c = c;
    }
};

class Circle: public Shape{
    private:
        int r;
    public:
        double getArea(){
            return PI*r*r;
        }
    Circle(int r):Shape(C){
        this->r = r;
    }
};

class Rectangle: public Shape{
    private:
        int w;
        int h;
    public:
        double getArea(){
            return w*h*1.0;
        }
    Rectangle(int w, int h):Shape(R){
        this->w = w;
        this->h = h;
    }
};

int main(){
    int n;
    segment array[15];
    scanf("%d", &n);
    for(int i=1;i<=n;i++){
        char type;
        getchar();
        scanf("%c", &type);
        /*if you want to add a new class:
        if(type == Type you define at first){
            int attributes...;
            input();
            NewClass obj(attributes...)
            array[i].name = obj.Name();
            array[i].value = obj.getArea();
        }
        */
        if(type == 'R'){
            int w,h;
            scanf("%d %d",&w, &h);
            Rectangle obj(w,h);
            array[i].name = obj.Name();
            array[i].value = obj.getArea();
        }
        if(type == 'C'){
            int r;
            scanf("%d",&r);
            Circle obj(r);
            array[i].name = obj.Name();
            array[i].value = obj.getArea();
        }
        if(type == 'T'){
            int a,b,c;
            scanf("%d %d %d",&a, &b, &c);
            Triangle obj(a, b, c);
            array[i].name = obj.Name();
            array[i].value = obj.getArea();
        }
    }
    sort(array+1,array+n+1);
    for(int i=1;i<=n;i++)
        cout << array[i].name << " " << array[i].value << endl;
    return 0;
}